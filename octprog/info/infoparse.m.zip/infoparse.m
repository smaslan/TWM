function [idata] = infoparse(inf)

    
    
    NL = sprintf('\n');
    
    inf = [NL inf NL];
    
    nls = find(inf==NL);
    
    
    % tokenize sections:
    keystr = {'#startsection','#endsection'};    
    for s = 1:numel(keystr)
    
        % look for candidates:      
        ss = strfind(inf,keystr{s});
        keystrlen = length(keystr{s});
        S = numel(ss);
        
        % for each candidate
        for k = 1:S
            
            % extract one row
            row_start = nls(find(nls < ss(k),1,'last')) + 1;
            row_end = nls(find(nls > ss(k),1)) - 1;        
            row = strtrim(inf(row_start:row_end));
            
            if strncmp(row,keystr{s},keystrlen)
                % the row starts with key-string, so it may be valid
            
                % look for separator
                qci = strfind(row,'::');
                if ~isempty(qci)
                    % is there, extract name                
                    name = strtrim(row(qci+2:end));
                    
                    if ~isempty(name)
                        % name present - it is valid key
                        
                        % store section name:
                        sec_name{end+1} = name;
                        % section data (start/end):
                        sec_start(end+1) = row_end + 1;
                        sec_end(end+1) = row_start - 1;                                                        
                        % store section key type (start/end):  
                        sec_type(end+1) = s;
                        % store section key position:
                        sec_pos(end+1) = row_start;                                            
                    end                        
                end
            end
        end
    end
    
    % sort tokens by position in string:
    [sec_pos,id] = sort(sec_pos);    
    sec_name = {sec_name{id},'_'}; 
    sec_start = [sec_start(id),1];
    sec_end = [sec_end(id),length(inf)];
    sec_type = [sec_type(id),2];
    
    % sections count
    N = numel(sec_type);
    idata = infoparse_struct(struct(),inf,1,1,N,sec_pos,sec_name,sec_start,sec_end,sec_type,'_');
        
end


function [idata,n,pos] = infoparse_struct(idata,inf,pos,n,N,sec_pos,sec_name,sec_start,sec_end,sec_type,name)
        
    % this section's data
    idata.data = '';
    idata.sec_names = {};
    idata.sections = {};
    
    while n <= N
        
        % collect this section's data (without sub-section's data):
        idata.data = [idata.data,inf(pos:sec_end(n))];
        % update parse position:
        pos = sec_start(n); 
    
        if sec_type(n) == 2
            % #endsection        
            if ~strcmp(name,sec_name{n})
                error(sprintf('info-bourator: inconsitent data in info-string! ''#endsection %s'' does not match ''#startsection %s''.',sec_name{n},name));    
            end
            % valid #endsection - return
            
            % return sections count:
            idata.sec_count = numel(idata.sec_names);
                  
            return;
            
        else
            % next #startsection
            
            % new section's name:
            new_name = sec_name{n};
            
            % go recursion:
            [sec_data,n,pos] = infoparse_struct(struct(),inf,pos,n+1,N,sec_pos,sec_name,sec_start,sec_end,sec_type,new_name);
                     
            % collect subsection data
            idata.sec_names{end+1} = new_name;
            idata.sections{end+1} = sec_data;        
            
        end
        
        % move to the next token:
        n = n + 1;
      
    end
     
    error(sprintf('info-bourator: inconsitent data in info-string! Missing ''#endsection %s''.',name));     
    
end