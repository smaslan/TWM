Note this is modified version of the INFO-STRINGS library!!!

Definitely not compatible with version on the WWW!!!

The new functions for handling string matrices were added and
numeric matrix reader was modified (was failing at empty matrix).
