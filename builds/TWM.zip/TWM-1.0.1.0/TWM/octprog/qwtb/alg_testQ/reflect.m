function [out1, out2] = reflect(in)  %<<<1
% Returns input on the first output, the second output is always empty matrix

out1 = in;
out2 = [];

end % function

% vim settings modeline: vim: foldmarker=%<<<,%>>> fdm=marker fen ft=octave textwidth=80 tabstop=4 shiftwidth=4
