This is temporary version of QWTB toolbox! Just for development.
It will be removed.

https://qwtb.github.io/qwtb/


todo:

All TWM algs:
 - separate aperture correction for high- low-side channel (only TWM-FPNLSF has it)
 - check the signs of the corrections!
